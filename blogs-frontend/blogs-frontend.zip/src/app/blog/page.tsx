"use client";

import BlogsPage from "@/components/business/BlogsPage";

export default function Page() {
  return <BlogsPage />;
}
